import React, { useState, useEffect, useRef } from 'react';
import { collection, getDocs, addDoc, updateDoc, deleteDoc, doc, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import { Loader2, Plus, Trash2, Image as ImageIcon, X } from 'lucide-react';

export default function ProductsManager() {
  const [products, setProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    color: '#ff2a75',
  });
  
  const [images, setImages] = useState<string[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const querySnapshot = await getDocs(collection(db, 'products'));
      const prods = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setProducts(prods);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setFormData({ name: '', description: '', color: '#ff2a75' });
    setImages([]);
    setIsAdding(false);
    setEditingId(null);
  };

  const handleEdit = (prod: any) => {
    setFormData({
      name: prod.name,
      description: prod.description,
      color: prod.color,
    });
    setImages(prod.images || []);
    setEditingId(prod.id);
    setIsAdding(false);
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Voulez-vous vraiment supprimer ce produit ?")) return;
    try {
      await deleteDoc(doc(db, 'products', id));
      fetchProducts();
    } catch (e) {
      console.error(e);
      alert("Erreur lors de la suppression.");
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (images.length === 0) {
      alert("Veuillez ajouter au moins une photo.");
      return;
    }
    
    try {
      setLoading(true);
      const data = {
        ...formData,
        images,
        updatedAt: serverTimestamp()
      };
      
      if (editingId) {
        await updateDoc(doc(db, 'products', editingId), data);
      } else {
        await addDoc(collection(db, 'products'), {
          ...data,
          createdAt: serverTimestamp()
        });
      }
      resetForm();
      fetchProducts();
    } catch (error) {
      console.error(error);
      alert("Erreur d'enregistrement.");
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    if (images.length + files.length > 4) {
      alert("Vous ne pouvez ajouter que 4 photos maximum par produit.");
      return;
    }

    Array.from(files).forEach((file: any) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 500;
          const MAX_HEIGHT = 500;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;

          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          // Compress heavily to avoid hitting Firestore 1MB document limit
          const compressedBase64 = canvas.toDataURL('image/jpeg', 0.5);
          setImages(prev => [...prev, compressedBase64]);
        };
        img.src = reader.result as string;
      };
      reader.readAsDataURL(file);
    });
    
    // Clear input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = (index: number) => {
    setImages(prev => prev.filter((_, i) => i !== index));
  };

  if (loading && !isAdding && !editingId) {
    return <div className="py-20 flex justify-center"><Loader2 size={32} className="animate-spin text-ink/50" /></div>;
  }

  return (
    <div className="space-y-6">
      {/* HEADER / ACTIONS */}
      {(!isAdding && !editingId) ? (
        <>
          <div className="flex justify-between items-center bg-white p-4 rounded-2xl shadow-sm border border-rose-soft/50">
             <div className="text-sm font-medium text-ink">Vos produits ({products.length})</div>
             <button 
               onClick={() => setIsAdding(true)}
               className="bg-ink text-white px-4 py-2 rounded-xl text-sm font-medium flex items-center gap-2 hover:bg-ink/90 transition-colors"
             >
               <Plus size={16} /> Ajouter un produit
             </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {products.map(p => (
              <div key={p.id} className="bg-white p-4 rounded-2xl shadow-sm border border-rose-soft/50 flex gap-4">
                <div className="w-24 h-32 bg-warm-white rounded-xl overflow-hidden flex-shrink-0">
                  {p.images && p.images[0] ? (
                    <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                  ) : <div className="w-full h-full flex items-center justify-center text-ink/20"><ImageIcon /></div>}
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <h4 className="font-bold text-ink">{p.name}</h4>
                    <p className="text-xs text-ink/60 mt-1 line-clamp-2">{p.description}</p>
                    <div className="mt-2 flex items-center gap-2 text-xs text-ink/50">
                      <div className="w-3 h-3 rounded-full" style={{ backgroundColor: p.color }}></div>
                      {p.images?.length || 0} photo(s)
                    </div>
                  </div>
                  <div className="flex items-center gap-2 mt-4">
                    <button onClick={() => handleEdit(p)} className="text-xs bg-ink/5 hover:bg-ink/10 text-ink px-3 py-1.5 rounded-lg flex-1">
                      Modifier
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="text-xs bg-red-50 text-red-600 hover:bg-red-100 px-3 py-1.5 rounded-lg">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        /* FORM ADD / EDIT */
        <div className="bg-white p-6 md:p-8 rounded-3xl shadow-sm border border-rose-soft/50">
           <h3 className="text-xl font-serif text-ink mb-6">{editingId ? 'Modifier le produit' : 'Nouveau Produit'}</h3>
           
           <form onSubmit={handleSave} className="space-y-6">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div>
                 <label className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2">Nom du produit</label>
                 <input 
                   required
                   value={formData.name}
                   onChange={e => setFormData({...formData, name: e.target.value})}
                   className="w-full bg-warm-white border border-rose-soft rounded-xl px-4 py-3 text-ink focus:outline-none focus:ring-2 focus:ring-ink"
                 />
               </div>
               <div>
                 <label className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2">Couleur thématique</label>
                 <div className="flex gap-2">
                   <input 
                     type="color"
                     value={formData.color}
                     onChange={e => setFormData({...formData, color: e.target.value})}
                     className="w-12 h-12 rounded-xl border border-rose-soft cursor-pointer"
                   />
                   <input 
                     value={formData.color}
                     onChange={e => setFormData({...formData, color: e.target.value})}
                     className="flex-1 bg-warm-white border border-rose-soft rounded-xl px-4 py-3 text-ink focus:outline-none focus:ring-2 focus:ring-ink"
                   />
                 </div>
               </div>
             </div>
             
             <div>
               <label className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2">Description</label>
               <input 
                 value={formData.description}
                 onChange={e => setFormData({...formData, description: e.target.value})}
                 className="w-full bg-warm-white border border-rose-soft rounded-xl px-4 py-3 text-ink focus:outline-none focus:ring-2 focus:ring-ink"
                 placeholder="Ex: Haut en soie & short élastique..."
               />
             </div>
             
             <div>
               <label className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2">
                 Photos du produit ({images.length})
               </label>
               
               <div className="flex flex-wrap gap-4">
                 {images.map((img, i) => (
                   <div key={i} className="relative w-24 h-32 rounded-xl overflow-hidden shadow-sm">
                     <img src={img} className="w-full h-full object-cover" />
                     <button 
                       type="button"
                       onClick={() => removeImage(i)}
                       className="absolute top-1 right-1 bg-white/80 p-1 rounded-full text-red-500 hover:bg-white"
                     >
                       <X size={14} />
                     </button>
                   </div>
                 ))}
                 
                 <div 
                   onClick={() => fileInputRef.current?.click()}
                   className="w-24 h-32 rounded-xl border-2 border-dashed border-rose-soft flex flex-col items-center justify-center text-ink/40 cursor-pointer hover:bg-warm-white hover:text-ink/60 transition-colors"
                 >
                   <Plus size={24} className="mb-1" />
                   <span className="text-[10px] font-medium uppercase text-center px-2">Ajouter Photo</span>
                 </div>
               </div>
               
               <input 
                 type="file" 
                 accept="image/*" 
                 multiple
                 className="hidden" 
                 ref={fileInputRef}
                 onChange={handleImageUpload}
               />
             </div>
             
             <div className="flex items-center gap-3 pt-6 border-t border-rose-soft/50">
               <button 
                 type="button" 
                 onClick={resetForm}
                 className="flex-1 bg-warm-white text-ink border border-rose-soft rounded-xl py-3.5 font-medium hover:bg-rose-soft/30 transition-colors"
               >
                 Annuler
               </button>
               <button 
                 type="submit"
                 disabled={loading}
                 className="flex-1 bg-ink text-white rounded-xl py-3.5 font-medium flex items-center justify-center gap-2 hover:bg-ink/90 disabled:opacity-70 transition-all"
               >
                 {loading && <Loader2 size={16} className="animate-spin" />}
                 {editingId ? 'Mettre à jour' : 'Enregistrer'}
               </button>
             </div>
           </form>
        </div>
      )}
    </div>
  );
}
