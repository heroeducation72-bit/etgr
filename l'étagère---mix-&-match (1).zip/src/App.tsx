import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, ShoppingBag, ArrowRight, ChevronDown, CheckCircle, Info, Settings, Upload, Truck, ShieldCheck, Star } from 'lucide-react';
import { collection, addDoc, serverTimestamp, doc, getDoc, setDoc, getDocs } from 'firebase/firestore';
import { db } from './firebase';
import AdminDashboard from './AdminDashboard';

// --- DATA ---
const WILAYAS = [
  "01 - Adrar", "02 - Chlef", "03 - Laghouat", "04 - Oum El Bouaghi", "05 - Batna", "06 - Béjaïa", "07 - Biskra", "08 - Béchar", "09 - Blida", "10 - Bouira",
  "11 - Tamanrasset", "12 - Tébessa", "13 - Tlemcen", "14 - Tiaret", "15 - Tizi Ouzou", "16 - Alger", "17 - Djelfa", "18 - Jijel", "19 - Sétif", "20 - Saïda",
  "21 - Skikda", "22 - Sidi Bel Abbès", "23 - Annaba", "24 - Guelma", "25 - Constantine", "26 - Médéa", "27 - Mostaganem", "28 - M'Sila", "29 - Mascara", "30 - Ouargla",
  "31 - Oran", "32 - El Bayadh", "33 - Illizi", "34 - Bordj Bou Arreridj", "35 - Boumerdès", "36 - El Tarf", "37 - Tindouf", "38 - Tissemsilt", "39 - El Oued", "40 - Khenchela",
  "41 - Souk Ahras", "42 - Tipaza", "43 - Mila", "44 - Aïn Defla", "45 - Naâma", "46 - Aïn Témouchent", "47 - Ghardaïa", "48 - Relizane", "49 - Timimoun", "50 - Bordj Badji Mokhtar",
  "51 - Ouled Djellal", "52 - Béni Abbès", "53 - In Salah", "54 - In Guezzam", "55 - Touggourt", "56 - Djanet", "57 - El M'Ghair", "58 - El Meniaa"
];

// Accurate shipping rates from Yalidine/E-com standard (Home / Desk)
const SHIPPING_RATES: Record<string, { home: number, desk: number }> = {
  "01": { home: 1400, desk: 900 }, "02": { home: 700, desk: 450 }, "03": { home: 950, desk: 600 }, "04": { home: 750, desk: 450 },
  "05": { home: 750, desk: 450 }, "06": { home: 750, desk: 400 }, "07": { home: 950, desk: 600 }, "08": { home: 1200, desk: 800 },
  "09": { home: 600, desk: 400 }, "10": { home: 650, desk: 400 }, "11": { home: 1800, desk: 1000 }, "12": { home: 850, desk: 550 },
  "13": { home: 850, desk: 450 }, "14": { home: 750, desk: 500 }, "15": { home: 750, desk: 400 }, "16": { home: 400, desk: 250 },
  "17": { home: 950, desk: 600 }, "18": { home: 750, desk: 450 }, "19": { home: 700, desk: 400 }, "20": { home: 800, desk: 500 },
  "21": { home: 750, desk: 450 }, "22": { home: 750, desk: 450 }, "23": { home: 800, desk: 400 }, "24": { home: 800, desk: 450 },
  "25": { home: 750, desk: 450 }, "26": { home: 750, desk: 450 }, "27": { home: 750, desk: 450 }, "28": { home: 750, desk: 450 },
  "29": { home: 750, desk: 450 }, "30": { home: 1000, desk: 650 }, "31": { home: 750, desk: 400 }, "32": { home: 950, desk: 700 },
  "33": { home: 1800, desk: 1200 }, "34": { home: 700, desk: 450 }, "35": { home: 650, desk: 400 }, "36": { home: 850, desk: 450 },
  "37": { home: 1800, desk: 1000 }, "38": { home: 750, desk: 500 }, "39": { home: 950, desk: 700 }, "40": { home: 800, desk: 450 },
  "41": { home: 850, desk: 450 }, "42": { home: 650, desk: 400 }, "43": { home: 750, desk: 450 }, "44": { home: 700, desk: 450 },
  "45": { home: 950, desk: 700 }, "46": { home: 850, desk: 450 }, "47": { home: 1000, desk: 600 }, "48": { home: 700, desk: 450 },
  "49": { home: 1500, desk: 750 }, "50": { home: 1800, desk: 1000 }, "51": { home: 1200, desk: 650 }, "52": { home: 1600, desk: 900 },
  "53": { home: 1800, desk: 1200 }, "54": { home: 1800, desk: 1000 }, "55": { home: 1200, desk: 700 }, "56": { home: 1800, desk: 1200 },
  "57": { home: 1200, desk: 600 }, "58": { home: 1200, desk: 700 }
};

type Product = {
  id: string;
  name: string;
  description: string;
  color: string; 
  images: string[];
}

const INITIAL_SETS: Product[] = [
  { id: 'set-bleu', name: 'Ensemble Bleu Royal', description: 'Haut bleu & Short cœurs bleus', color: '#163ea6', images: ['/pyjama-bleu.jpg'] },
  { id: 'set-noir', name: 'Ensemble Noir Élégant', description: 'Haut noir & Short rose cœurs noirs', color: '#1a1a1a', images: ['/pyjama-noir.jpg'] },
  { id: 'set-rose', name: 'Ensemble Rose Fluo', description: 'Haut rose fluo & Short cœurs roses', color: '#ff2a75', images: ['/pyjama-rose.jpg'] },
  { id: 'set-rouge', name: 'Ensemble Rouge Passion', description: 'Haut rouge & Short cœurs rouges', color: '#cc0e1d', images: ['/pyjama-rouge.jpg'] },
];

const PRICE_1 = 1600;
const PRICE_2 = 2900;
const PRICE_3 = 3900;

// --- COMPONENTS ---
function ImagePlaceholder({ 
  text, 
  color = '#f4e8e6', 
  active = false, 
  images = [] 
}: { 
  text: string, 
  color?: string, 
  active?: boolean, 
  images?: string[] 
}) {
  const [currentIdx, setCurrentIdx] = useState(0);

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (images.length > 0) {
      setCurrentIdx((prev) => (prev + 1) % images.length);
    }
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (images.length > 0) {
      setCurrentIdx((prev) => (prev - 1 + images.length) % images.length);
    }
  };

  return (
    <div 
      className={`w-full aspect-[3/4] rounded-2xl relative overflow-hidden transition-all duration-300 ${active ? 'ring-2 ring-ink ring-offset-4 ring-offset-warm-white' : ''}`}
      style={{ backgroundColor: color }}
    >
      {images && images.length > 0 ? (
        <>
          <img 
            src={images[currentIdx]} 
            alt={text} 
            className="w-full h-full object-cover transition-transform duration-700 hover:scale-105"
          />
          {images.length > 1 && (
            <>
              {/* Dots indicator */}
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10 bg-black/20 px-2 py-1 rounded-full backdrop-blur-sm">
                {images.map((_, i) => (
                  <div key={i} className={`w-1.5 h-1.5 rounded-full transition-colors ${i === currentIdx ? 'bg-white' : 'bg-white/50'}`} />
                ))}
              </div>
              {/* Navigation Arrows */}
              <button onClick={handlePrev} className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/70 hover:bg-white text-ink p-1 rounded-full shadow-sm z-10 transition-colors">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>
              </button>
              <button onClick={handleNext} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/70 hover:bg-white text-ink p-1 rounded-full shadow-sm z-10 transition-colors">
                 <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>
              </button>
            </>
          )}
        </>
      ) : (
        <div className="absolute inset-0 flex items-center justify-center p-4 text-center">
          <span className="font-sans text-xs tracking-widest text-ink/80 uppercase bg-white/70 backdrop-blur-sm px-4 py-2 rounded-full shadow-sm">
            {text}
          </span>
        </div>
      )}
      
      {active && (
        <div className="absolute top-4 right-4 bg-ink text-warm-white rounded-full p-1.5 shadow-md z-20">
          <Check size={16} strokeWidth={3} />
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [currentView, setCurrentView] = useState<'shop' | 'admin'>('shop');
  const [selectedPackQty, setSelectedPackQty] = useState<number | null>(null);
  const [selectedSets, setSelectedSets] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});
  const [selectedWilaya, setSelectedWilaya] = useState<string>('');
  const [deliveryType, setDeliveryType] = useState<'home' | 'desk'>('home');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [orderSuccess, setOrderSuccess] = useState(false);
  
  const [products, setProducts] = useState<Product[]>([]);
  const [isAdminMode, setIsAdminMode] = useState(false);

  useEffect(() => {
    // Handle routing based on hash
    const handleHashChange = () => {
      if (window.location.hash === '#admin') {
        setCurrentView('admin');
        setIsAdminMode(false);
      } else if (window.location.hash === '#shop-edit') {
        setCurrentView('shop');
        setIsAdminMode(true);
      } else {
        setCurrentView('shop');
        setIsAdminMode(false);
      }
    };
    
    // Initial check
    handleHashChange();
    
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Load images from FIRESTORE on mount
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const querySnapshot = await getDocs(collection(db, 'products'));
        if (querySnapshot.empty) {
          setProducts(INITIAL_SETS);
        } else {
          setProducts(querySnapshot.docs.map(doc => {
            const data = doc.data() as Product;
            // Fallback for default products if their images are empty
            if ((!data.images || data.images.length === 0) && INITIAL_SETS.find(s => s.id === doc.id)) {
                data.images = INITIAL_SETS.find(s => s.id === doc.id)?.images || [];
            }
            return { id: doc.id, ...data };
          }));
        }
      } catch (e) {
        console.error("Erreur de chargement des produits", e);
        setProducts(INITIAL_SETS);
      }
    };
    fetchProducts();
  }, []);

  const handleSizeSelect = (id: string, size: string) => {
    if (!selectedPackQty) {
      alert("Veuillez d'abord choisir votre offre (Pack) plus haut !");
      document.getElementById('packs-section')?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    const maxQty = selectedPackQty;

    if (selectedSets.includes(id)) {
      if (selectedSizes[id] === size) {
         setSelectedSets(selectedSets.filter(s => s !== id));
         const newSizes = { ...selectedSizes };
         delete newSizes[id];
         setSelectedSizes(newSizes);
      } else {
         setSelectedSizes({ ...selectedSizes, [id]: size });
      }
    } else {
      if (selectedSets.length < maxQty) {
        setSelectedSets([...selectedSets, id]);
        setSelectedSizes({ ...selectedSizes, [id]: size });
      } else {
        const newSets = [...selectedSets.slice(1), id];
        const newSizes = { ...selectedSizes };
        delete newSizes[selectedSets[0]];
        newSizes[id] = size;
        setSelectedSets(newSets);
        setSelectedSizes(newSizes);
      }
    }
  };

  const toggleSet = (id: string) => {
    if (isAdminMode) return;
    if (!selectedPackQty) {
      alert("Veuillez d'abord choisir votre offre (Pack) plus haut !");
      document.getElementById('packs-section')?.scrollIntoView({ behavior: 'smooth' });
      return;
    }
    
    if (selectedSets.includes(id)) {
      setSelectedSets(selectedSets.filter(s => s !== id));
      const newSizes = { ...selectedSizes };
      delete newSizes[id];
      setSelectedSizes(newSizes);
    } else {
      handleSizeSelect(id, 'M');
    }
  };

  const productsPrice = selectedPackQty === 3 ? PRICE_3 : (selectedPackQty === 2 ? PRICE_2 : (selectedPackQty === 1 ? PRICE_1 : 0));
  
  const getShippingFee = (wilayaString: string) => {
    if (!wilayaString) return 0;
    const code = wilayaString.split(' - ')[0]; // Gets "01", "16", etc.
    return SHIPPING_RATES[code]?.[deliveryType] || 600; // Returns map value or defaults to 600
  };
  
  const shippingFee = getShippingFee(selectedWilaya);
  const totalPrice = productsPrice + shippingFee;

  const handleOrderSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (selectedSets.length === 0) return;

    setIsSubmitting(true);
    
    const formData = new FormData(e.currentTarget);
    const orderData = {
      customer: {
        name: formData.get('fullName'),
        phone: formData.get('phone'),
        wilaya: selectedWilaya,
        commune: formData.get('commune'),
        deliveryType: deliveryType,
      },
      selections: selectedSets.map(id => `${products.find(s => s.id === id)?.name} (Taille: ${selectedSizes[id]})`),
      quantity: selectedSets.length,
      productsPrice: productsPrice,
      shippingFee: shippingFee,
      total: totalPrice,
      currency: 'DA',
      status: 'pending',
      createdAt: serverTimestamp()
    };

    try {
      await addDoc(collection(db, 'orders'), orderData);
      setOrderSuccess(true);
      // Fire Meta Pixel Purchase event
      if (typeof (window as any).fbq === 'function') {
        (window as any).fbq('track', 'Purchase', {
          value: totalPrice,
          currency: 'DZD'
        });
      }
    } catch (error) {
      console.error("Erreur lors de l'envoi de la commande:", error);
      alert("Une erreur s'est produite. Veuillez vérifier votre connexion et réessayer.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (currentView === 'admin') {
    return <AdminDashboard onBack={() => { window.location.hash = ''; }} />;
  }

  if (orderSuccess) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center p-6 text-center">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }} 
          animate={{ scale: 1, opacity: 1 }}
          className="bg-white p-8 rounded-3xl shadow-xl max-w-sm w-full border border-rose-soft"
        >
          <div className="mx-auto w-16 h-16 bg-green-50 text-green-600 rounded-full flex items-center justify-center mb-6">
            <CheckCircle size={32} />
          </div>
          <h1 className="text-3xl font-serif mb-2 text-ink">Commande Validée</h1>
          <p className="text-ink/60 font-sans mb-8">
            Merci pour votre commande ! L'équipe L'étagère vous contactera très prochainement pour la livraison.
          </p>
          <button 
            onClick={() => {
              setOrderSuccess(false);
              setSelectedSets([]);
              setSelectedSizes({});
            }}
            className="w-full bg-ink text-white rounded-full py-4 font-medium tracking-wide uppercase text-sm hover:opacity-90 transition-opacity"
          >
            Retour à la boutique
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pb-24 relative">
      {/* HEADER */}
      <header className="sticky top-0 z-50 bg-warm-white/80 backdrop-blur-md border-b border-rose-soft/50 px-6 py-4 flex justify-between items-center">
        <div className="text-2xl font-serif font-semibold tracking-tight text-ink">L'étagère</div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm font-medium">
            <ShoppingBag size={18} />
            <span className="bg-rose-accent/20 px-3 py-1 rounded-full text-ink flex items-center gap-2">
              Panier: {selectedSets.length}
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-6 pt-12">
        {/* HERO SECTION */}
        <section className="text-center mb-12">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <h2 className="text-[11px] font-sans uppercase tracking-[0.2em] text-ink/50 mb-4 font-semibold">
              Nouvelle Collection
            </h2>
            <h1 className="text-4xl sm:text-6xl font-serif leading-[0.95] tracking-tight text-ink mb-6">
              Soyez stylé et à l'aise cet été.
            </h1>
            <p className="text-lg font-serif italic text-ink/70 mb-4 max-w-md mx-auto">
              Le confort absolu pour vos journées et nuits.
            </p>
            
            {/* TRUST BADGES */}
            <div className="flex flex-wrap justify-center gap-3 mt-8 mb-16 text-[11px] sm:text-xs font-medium text-ink/80">
              <span className="flex items-center gap-1.5 bg-white px-4 py-2 rounded-full shadow-sm border border-rose-soft whitespace-nowrap">
                <Truck size={14} className="text-rose-accent"/> Livraison 58 Wilayas
              </span>
              <span className="flex items-center gap-1.5 bg-white px-4 py-2 rounded-full shadow-sm border border-rose-soft whitespace-nowrap">
                <ShieldCheck size={14} className="text-rose-accent"/> Paiement à la livraison
              </span>
              <span className="flex items-center gap-1.5 bg-white px-4 py-2 rounded-full shadow-sm border border-rose-soft whitespace-nowrap">
                <Star size={14} className="text-rose-accent"/> Échange possible
              </span>
            </div>

            {/* PACKS SECTION */}
            <div id="packs-section" className="scroll-mt-24">
              <div className="flex items-center justify-center gap-2 mb-6">
                 <h3 className="text-2xl font-serif text-ink tracking-tight">Étape 1 : Choisissez votre offre</h3>
                 <span className="ml-2 bg-rose-accent text-white px-2 py-0.5 rounded text-[10px] uppercase font-bold animate-pulse">Offre aujourd'hui</span>
              </div>
              <div className="space-y-4">
                {/* Pack 1 */}
                <div 
                  onClick={() => { setSelectedPackQty(1); document.getElementById('selection-section')?.scrollIntoView({ behavior: 'smooth' }); }}
                  className={`cursor-pointer bg-white border ${selectedPackQty === 1 ? 'border-ink shadow-md' : 'border-rose-soft/50 shadow-sm hover:border-ink/50'} rounded-2xl p-5 flex flex-col sm:flex-row justify-between items-center sm:items-start text-left gap-4 transition-all`}
                >
                  <div className="text-center sm:text-left w-full sm:w-auto">
                    <h4 className="text-lg font-bold text-ink">1 Ensemble</h4>
                    <p className="text-sm text-ink/60 mt-1">L'essentiel pour commencer</p>
                  </div>
                  <div className="flex flex-col items-center sm:items-end w-full sm:w-auto">
                    <span className="text-2xl font-serif font-bold text-ink">{PRICE_1} DA</span>
                    <button className={`mt-2 w-full sm:w-auto px-6 py-2 rounded-full font-medium text-sm transition-all ${selectedPackQty === 1 ? 'bg-ink text-white' : 'bg-warm-white text-ink border border-ink/20'}`}>
                      {selectedPackQty === 1 ? 'Sélectionné' : 'Commander'}
                    </button>
                  </div>
                </div>

                {/* Pack 2 - BEST SELLER */}
                <div 
                  onClick={() => { setSelectedPackQty(2); document.getElementById('selection-section')?.scrollIntoView({ behavior: 'smooth' }); }}
                  className={`relative cursor-pointer bg-rose-soft/20 border-2 ${selectedPackQty === 2 ? 'border-rose-accent shadow-lg shadow-rose-accent/10 scale-[1.02]' : 'border-rose-accent/50 shadow-md hover:border-rose-accent scale-[1.01]'} rounded-2xl p-6 flex flex-col sm:flex-row justify-between items-center sm:items-start text-left gap-4 transition-all`}
                >
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 sm:left-6 sm:translate-x-0 bg-rose-accent text-white px-3 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-sm whitespace-nowrap">
                    🔥 Le plus choisi
                  </div>
                  <div className="mt-2 sm:mt-0 text-center sm:text-left w-full sm:w-auto">
                    <h4 className="text-xl font-bold text-ink">Pack de 2 Ensembles</h4>
                    <p className="text-sm font-medium text-rose-accent mt-1">Économisez + meilleur rapport qualité/prix</p>
                  </div>
                  <div className="flex flex-col items-center sm:items-end w-full sm:w-auto">
                    <span className="text-3xl font-serif font-bold text-rose-accent">{PRICE_2} DA</span>
                    <button className={`mt-2 w-full sm:w-auto px-8 py-2.5 rounded-full font-bold text-sm transition-all ${selectedPackQty === 2 ? 'bg-rose-accent text-white shadow-md' : 'bg-white text-rose-accent border border-rose-accent/30'}`}>
                      {selectedPackQty === 2 ? 'Sélectionné' : 'Commander maintenant'}
                    </button>
                  </div>
                </div>

                {/* Pack 3 */}
                <div 
                  onClick={() => { setSelectedPackQty(3); document.getElementById('selection-section')?.scrollIntoView({ behavior: 'smooth' }); }}
                  className={`relative cursor-pointer bg-ink/5 border ${selectedPackQty === 3 ? 'border-ink shadow-md' : 'border-ink/10 shadow-sm hover:border-ink/40'} rounded-2xl p-5 flex flex-col sm:flex-row justify-between items-center sm:items-start text-left gap-4 transition-all`}
                >
                  <div className="absolute -top-3 left-1/2 -translate-x-1/2 sm:left-6 sm:translate-x-0 bg-ink text-white px-3 py-0.5 rounded-full text-[11px] font-bold uppercase tracking-wider shadow-sm whitespace-nowrap">
                    💣 Meilleure offre
                  </div>
                  <div className="mt-2 sm:mt-0 text-center sm:text-left w-full sm:w-auto">
                    <h4 className="text-lg font-bold text-ink">Pack de 3 Ensembles</h4>
                    <p className="text-sm text-ink/70 mt-1">3 pour seulement 1300 DA / pièce</p>
                  </div>
                  <div className="flex flex-col items-center sm:items-end w-full sm:w-auto">
                    <span className="text-2xl font-serif font-bold text-ink">{PRICE_3} DA</span>
                    <button className={`mt-2 w-full sm:w-auto px-6 py-2 rounded-full font-medium text-sm transition-all ${selectedPackQty === 3 ? 'bg-ink text-white' : 'bg-white text-ink border border-ink/20'}`}>
                      {selectedPackQty === 3 ? 'Sélectionné' : 'Commander'}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </section>

        {/* SELECTION GRID */}
        <AnimatePresence>
          {selectedPackQty !== null && (
            <motion.section 
              id="selection-section"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              className="mt-16 mb-20 scroll-mt-24"
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 border-b border-ink/10 pb-4">
                <h3 className="text-2xl font-serif text-ink tracking-tight">Étape 2 : Choisissez vos couleurs</h3>
                <span className="text-xs font-sans uppercase tracking-widest text-ink bg-rose-soft/60 px-4 py-2 rounded-full font-bold flex-shrink-0 text-center">
                  {selectedSets.length} / {selectedPackQty} choisi(s)
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-x-4 gap-y-10">
            {products.map((set) => {
              const isActive = selectedSets.includes(set.id);
              
              return (
                <div key={set.id} className="relative">
                  <div className="group flex flex-col items-center text-left relative w-full">
                    <div 
                      onClick={() => toggleSet(set.id)}
                      className={`w-full mb-4 relative cursor-pointer ${isAdminMode ? 'opacity-50 pointer-events-none' : ''}`}
                    >
                      <ImagePlaceholder text={set.name} color={set.color} active={isActive && !isAdminMode} images={set.images} />
                    </div>
                    <span className="font-serif text-lg font-medium text-ink w-full leading-tight">{set.name}</span>
                    <span className="font-sans text-xs text-ink/50 w-full mt-1.5">{set.description}</span>
                    
                    {!isAdminMode && (
                      <div className="w-full mt-4 flex flex-col items-start gap-2.5">
                        <div className="text-[10px] uppercase tracking-widest text-ink/40 font-semibold">Sélectionnez la Taille :</div>
                        <div className="flex gap-2 w-full">
                          {['M', 'L', 'XL', 'XXL'].map(sz => (
                            <button
                              key={sz}
                              type="button"
                              onClick={() => handleSizeSelect(set.id, sz)}
                              className={`flex-1 min-w-[2.5rem] h-10 rounded-xl flex items-center justify-center text-xs font-bold transition-all ${isActive && selectedSizes[set.id] === sz ? 'bg-rose-accent text-white shadow-md border-rose-accent' : 'bg-warm-white border border-rose-soft text-ink/70 hover:border-ink hover:text-ink'}`}
                            >
                              {sz}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
            </motion.section>
          )}
        </AnimatePresence>

        {/* ORDER FORM */}
        <AnimatePresence>
          {selectedPackQty && selectedSets.length > 0 && !isAdminMode && (
            <motion.section 
              initial={{ opacity: 0, height: 0, y: 20 }}
              animate={{ opacity: 1, height: 'auto', y: 0 }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              className="bg-white rounded-[2rem] p-6 sm:p-10 shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-rose-soft mb-12 scroll-mt-24"
              id="order-section"
            >
              <div className="mb-8 text-center">
                <h3 className="text-3xl font-serif text-ink mb-2">Finaliser la commande</h3>
                <p className="text-ink/50 font-sans text-sm">Paiement à la livraison (COD)</p>
              </div>

              {/* Dynamic Summary */}
              <div className="bg-warm-white rounded-2xl p-6 mb-8 border border-ink/5 relative overflow-hidden">
                <h4 className="font-sans text-xs uppercase tracking-widest text-ink/50 mb-5 font-semibold">Votre Panier</h4>
                
                {selectedSets.map((id, index) => {
                  const set = products.find(s => s.id === id);
                  return (
                    <div key={id} className="flex justify-between items-center mb-4 last:mb-0">
                      <div className="flex items-center gap-3">
                        <span className="flex-shrink-0 w-6 h-6 rounded-full bg-rose-soft text-ink/60 flex items-center justify-center text-xs font-bold">
                          {index + 1}
                        </span>
                        <div className="flex flex-col">
                          <span className="text-ink font-medium leading-tight">{set?.name}</span>
                          <span className="text-rose-accent font-bold text-[11px] mt-0.5">Taille {selectedSizes[id]}</span>
                        </div>
                      </div>
                      <Check size={16} className="text-rose-accent flex-shrink-0" />
                    </div>
                  );
                })}

                {selectedSets.length < selectedPackQty && (
                  <div className="mt-4 pt-4 border-t border-rose-soft/50 flex items-start gap-2 text-rose-accent/80 text-sm">
                    <Info size={16} className="flex-shrink-0 mt-0.5" />
                    <p>Il vous reste {selectedPackQty - selectedSets.length} article(s) à choisir pour valider votre offre.</p>
                  </div>
                )}

                <div className="mt-6 pt-5 border-t border-ink/10 space-y-2">
                  <div className="flex justify-between items-end text-sm text-ink/70">
                    <span>Sous-total pyjamas</span>
                    <div className="text-right flex items-center gap-2">
                      {selectedPackQty > 1 && (
                        <span className="text-xs line-through text-ink/30">{PRICE_1 * selectedPackQty} DA</span>
                      )}
                      <span className="font-medium text-ink">{productsPrice} DA</span>
                    </div>
                  </div>
                  
                  {selectedWilaya && (
                    <div className="flex justify-between items-end text-sm text-ink/70">
                      <span>Livraison ({deliveryType === 'home' ? 'À domicile' : 'Point de relais'})</span>
                      <span className="font-medium text-ink">{shippingFee} DA</span>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-end pt-3 border-t border-ink/5 mt-3">
                    <span className="text-ink font-medium">Total à payer</span>
                    <span className="text-3xl font-serif text-ink font-semibold">{totalPrice} DA</span>
                  </div>
                </div>
              </div>

              {/* Form */}
              <form onSubmit={handleOrderSubmit} className="space-y-5">
                <div>
                  <label htmlFor="fullName" className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2 ml-1">Nom Complet</label>
                  <input 
                    type="text" 
                    id="fullName" 
                    name="fullName" 
                    required
                    className="w-full bg-warm-white border border-rose-soft rounded-xl px-4 py-3.5 text-ink focus:outline-none focus:ring-2 focus:ring-ink transition-all placeholder:text-ink/30"
                    placeholder="Ex: Sarah Benali"
                  />
                </div>
                
                <div>
                  <label htmlFor="phone" className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2 ml-1">Numéro de téléphone</label>
                  <input 
                    type="tel" 
                    id="phone" 
                    name="phone" 
                    required
                    dir="ltr"
                    className="w-full bg-warm-white border border-rose-soft rounded-xl px-4 py-3.5 text-ink focus:outline-none focus:ring-2 focus:ring-ink transition-all placeholder:text-ink/30"
                    placeholder="05 55 55 55 55"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="relative">
                    <label htmlFor="wilaya" className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2 ml-1">Wilaya (Calcul Livraison)</label>
                    <select 
                      id="wilaya" 
                      name="wilaya" 
                      required
                      className="w-full appearance-none bg-warm-white border border-rose-soft rounded-xl px-4 py-3.5 text-ink focus:outline-none focus:ring-2 focus:ring-ink transition-all"
                      value={selectedWilaya}
                      onChange={(e) => setSelectedWilaya(e.target.value)}
                    >
                      <option value="" disabled>Sélectionnez...</option>
                      {WILAYAS.map(w => <option key={w} value={w}>{w}</option>)}
                    </select>
                    <div className="absolute right-4 bottom-3.5 pointer-events-none text-ink/40">
                      <ChevronDown size={18} />
                    </div>
                  </div>

                  <div>
                     <label htmlFor="commune" className="block text-xs font-sans uppercase tracking-wider text-ink/60 mb-2 ml-1">Commune / Adresse</label>
                     <input 
                       type="text" 
                       id="commune" 
                       name="commune" 
                       required
                       className="w-full bg-warm-white border border-rose-soft rounded-xl px-4 py-3.5 text-ink focus:outline-none focus:ring-2 focus:ring-ink transition-all placeholder:text-ink/30"
                       placeholder="Votre adresse complete"
                     />
                  </div>
                </div>

                <div className="bg-warm-white border border-rose-soft rounded-xl p-1.5 flex gap-1 sm:gap-2">
                  <button
                    type="button"
                    onClick={() => setDeliveryType('home')}
                    className={`flex-1 py-3 px-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${deliveryType === 'home' ? 'bg-white shadow border border-ink/10 text-ink' : 'text-ink/60 hover:bg-ink/5'}`}
                  >
                    À Domicile {selectedWilaya ? `(+${SHIPPING_RATES[selectedWilaya.split(' - ')[0]]?.home || 600} DA)` : ''}
                  </button>
                  <button
                    type="button"
                    onClick={() => setDeliveryType('desk')}
                    className={`flex-1 py-3 px-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${deliveryType === 'desk' ? 'bg-white shadow border border-ink/10 text-ink' : 'text-ink/60 hover:bg-ink/5'}`}
                  >
                    Point Relais {selectedWilaya ? `(+${SHIPPING_RATES[selectedWilaya.split(' - ')[0]]?.desk || 400} DA)` : ''}
                  </button>
                </div>

                <div className="pt-6">
                  <button 
                    type="submit" 
                    disabled={isSubmitting || selectedSets.length < selectedPackQty}
                    className="group w-full bg-ink text-white rounded-xl py-4.5 font-medium tracking-wide flex items-center justify-center gap-3 hover:bg-ink/90 transition-all disabled:opacity-50"
                  >
                    {isSubmitting ? (
                      <span className="animate-pulse">Traitement en cours...</span>
                    ) : selectedSets.length < selectedPackQty ? (
                      `Choisissez encore ${selectedPackQty - selectedSets.length} article(s)`
                    ) : (
                      <>
                        Confirmer à {totalPrice} DA
                        <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                      </>
                    )}
                  </button>
                  <p className="text-center text-xs text-ink/40 mt-4 font-sans">
                    Vos informations sont sécurisées. Vous ne payez qu'à la livraison.
                  </p>
                </div>
              </form>
            </motion.section>
          )}
        </AnimatePresence>

        {/* REVIEWS SECTION */}
        <section className="mt-24 border-t border-rose-soft/50 pt-16 mb-6">
          <div className="text-center mb-12">
            <h3 className="text-3xl font-serif text-ink mb-2">Ce que nos clientes disent</h3>
            <p className="text-ink/60 font-sans text-sm">Note moyenne de 4.9/5 basée sur +500 commandes à travers les 58 Wilayas.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
             <div className="bg-white p-6 rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-rose-soft/50 hover:-translate-y-1 transition-transform duration-300">
                <div className="flex text-yellow-400 mb-4"><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/></div>
                <p className="text-ink/80 text-sm mb-6 leading-relaxed line-clamp-4">"Pyjama super doux, la livraison a été très rapide sur Alger et le livreur était gentil. Je recommande vraiment cette boutique, c'est mon deuxième achat !"</p>
                <p className="font-medium text-xs text-ink uppercase tracking-wide">— Sarah B. <span className="text-rose-accent ml-2 text-[10px] bg-rose-soft/20 px-2 py-0.5 rounded-full">Acheteur vérifié</span></p>
             </div>
             
             <div className="bg-white p-6 rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-rose-soft/50 hover:-translate-y-1 transition-transform duration-300">
                <div className="flex text-yellow-400 mb-4"><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/></div>
                <p className="text-ink/80 text-sm mb-6 leading-relaxed line-clamp-4">"Très belle qualité. J'ai pris le pack promotionnel de 2 ensembles, le tissu est agréable à porter, les tailles correspondent parfaitement et les couleurs sont superbes."</p>
                <p className="font-medium text-xs text-ink uppercase tracking-wide">— Amira F. <span className="text-rose-accent ml-2 text-[10px] bg-rose-soft/20 px-2 py-0.5 rounded-full">Acheteur vérifié</span></p>
             </div>
             
             <div className="bg-white p-6 rounded-2xl shadow-[0_4px_20px_rgb(0,0,0,0.03)] border border-rose-soft/50 hover:-translate-y-1 transition-transform duration-300">
                <div className="flex text-yellow-400 mb-4"><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/><Star size={16} fill="currentColor" stroke="none"/></div>
                <p className="text-ink/80 text-sm mb-6 leading-relaxed line-clamp-4">"C'était pour un cadeau, ma sœur a adoré la matière ! Emballage très propre. Merci l'étagère, je reviendrai commander pour moi cette fois-ci 🥰"</p>
                <p className="font-medium text-xs text-ink uppercase tracking-wide">— Meriem D. <span className="text-rose-accent ml-2 text-[10px] bg-rose-soft/20 px-2 py-0.5 rounded-full">Acheteur vérifié</span></p>
             </div>
          </div>
        </section>

      </main>
    </div>
  );
}
