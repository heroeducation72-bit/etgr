import React, { useState, useEffect } from 'react';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { signInWithPopup, GoogleAuthProvider, onAuthStateChanged, User, signOut } from 'firebase/auth';
import { db, auth } from './firebase';
import { Shield, Package, LogOut, Loader2, ArrowLeft, Tag } from 'lucide-react';
import ProductsManager from './ProductsManager';

export default function AdminDashboard({ onBack }: { onBack: () => void }) {
  const [user, setUser] = useState<User | null>(null);
  const [orders, setOrders] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState<'orders' | 'products'>('orders');

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      if (currentUser) {
        fetchOrders();
      } else {
        setLoading(false);
      }
    });
    return () => unsubscribe();
  }, []);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      setError('');
      const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
      const snapshot = await getDocs(q);
      const ordersData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setOrders(ordersData);
    } catch (err: any) {
      console.error(err);
      setError("Erreur de permission ou problème réseau. Seul l'administrateur peut voir les commandes.");
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async () => {
    try {
      setError('');
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      console.error(err);
      if (err.code === 'auth/popup-blocked') {
        setError("Erreur: Votre navigateur a bloqué la fenêtre de connexion. Veuillez autoriser les fenêtres pop-up pour ce site.");
      } else if (err.code === 'auth/unauthorized-domain') {
        setError("Erreur: Ce domaine n'est pas encore autorisé sur Firebase. Attendez 2 minutes le temps que Google mette à jour.");
      } else {
        setError("Erreur de connexion: " + err.message);
      }
    }
  };

  const handleLogout = () => {
    signOut(auth);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-warm-white flex items-center justify-center p-6">
        <div className="bg-white p-8 rounded-3xl shadow-sm border border-rose-soft max-w-sm w-full text-center">
          <Shield size={48} className="mx-auto text-ink/20 mb-4" />
          <h1 className="text-2xl font-serif text-ink mb-2">Espace Admin</h1>
          <p className="text-ink/60 font-sans text-sm mb-6">Connectez-vous pour voir les commandes</p>
          <button 
            onClick={handleLogin}
            className="w-full bg-ink text-white rounded-xl py-3 font-medium transition-opacity hover:opacity-90"
          >
            Se connecter avec Google
          </button>
          
          <button onClick={onBack} className="mt-4 text-sm text-ink/50 hover:text-ink transition-colors flex items-center justify-center gap-2 w-full">
            <ArrowLeft size={14} /> Retour à la boutique
          </button>
          
          {error && <p className="text-red-500 text-xs mt-4">{error}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-warm-white p-6 md:p-12">
      <div className="max-w-4xl mx-auto">
        <header className="flex justify-between items-center mb-8 border-b border-ink/10 pb-6 flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-serif text-ink">Espace Admin</h1>
            <p className="text-ink/60 text-sm">Vous êtes connecté en tant que {user.email}</p>
          </div>
          <div className="flex items-center gap-2 sm:gap-4 flex-wrap">
            <button 
              onClick={() => onBack()}
              className="flex items-center gap-2 bg-ink text-white hover:bg-ink/90 px-4 py-2 rounded-xl transition-colors text-sm font-medium"
            >
             <ArrowLeft size={16} /> Voir le site
            </button>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-2 bg-ink/5 hover:bg-ink/10 text-ink px-4 py-2 rounded-xl transition-colors text-sm font-medium"
            >
              <LogOut size={16} /> Déconnexion
            </button>
          </div>
        </header>

        <div className="flex gap-4 mb-8">
          <button 
            onClick={() => setActiveTab('orders')}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-medium transition-colors ${activeTab === 'orders' ? 'bg-ink text-white shadow-md' : 'bg-white text-ink/70 hover:bg-ink/5 border border-rose-soft'}`}
          >
            <Package size={18} /> Commandes ({orders.length})
          </button>
          <button 
            onClick={() => setActiveTab('products')}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-medium transition-colors ${activeTab === 'products' ? 'bg-ink text-white shadow-md' : 'bg-white text-ink/70 hover:bg-ink/5 border border-rose-soft'}`}
          >
            <Tag size={18} /> Produits
          </button>
        </div>

        {activeTab === 'products' ? (
          <ProductsManager />
        ) : loading ? (
          <div className="flex flex-col items-center justify-center py-20 text-ink/50">
            <Loader2 size={32} className="animate-spin mb-4" />
            <p>Chargement des commandes...</p>
          </div>
        ) : error ? (
           <div className="bg-red-50 text-red-600 p-6 rounded-2xl border border-red-100 text-center">
             <p>{error}</p>
             <button onClick={handleLogout} className="mt-4 text-sm underline">Changer de compte</button>
           </div>
        ) : orders.length === 0 ? (
          <div className="bg-white p-12 rounded-3xl shadow-sm border border-rose-soft text-center">
            <Package size={48} className="mx-auto text-ink/20 mb-4" />
            <h3 className="text-xl font-serif text-ink mb-2">Aucune commande</h3>
            <p className="text-ink/50 text-sm">Les prochaines commandes apparaîtront ici.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order) => (
              <div key={order.id} className="bg-white p-6 rounded-2xl shadow-sm border border-rose-soft/50 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="font-sans font-semibold text-lg text-ink">{order.customer?.name}</span>
                    <span className="bg-rose-soft/50 text-ink/70 text-xs px-2 py-1 rounded-md font-medium">{order.currency} {order.total}</span>
                    <span className="bg-ink/5 text-ink/50 text-xs px-2 py-1 rounded-md">Il y a {(order.createdAt ? new Date(order.createdAt.seconds * 1000).toLocaleDateString() : 'maintenant')}</span>
                  </div>
                  <div className="text-sm text-ink/60 space-y-1">
                    <p>📞 {order.customer?.phone}</p>
                    <p>📍 {order.customer?.wilaya} - {order.customer?.commune}</p>
                    {order.shippingFee !== undefined && (
                      <p className="inline-block bg-ink/5 px-2 py-0.5 rounded text-xs mt-1">
                        Livraison ({order.customer?.deliveryType === 'desk' ? 'Point relais' : 'À domicile'}): {order.shippingFee} DA
                      </p>
                    )}
                  </div>
                </div>
                
                <div className="bg-warm-white p-4 rounded-xl flex-1 md:max-w-xs border border-ink/5">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-ink/50 mb-2">Articles ({order.quantity})</h4>
                  <ul className="text-sm text-ink space-y-1">
                    {order.selections?.map((item: string, idx: number) => (
                      <li key={idx}>• {item}</li>
                    ))}
                  </ul>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
